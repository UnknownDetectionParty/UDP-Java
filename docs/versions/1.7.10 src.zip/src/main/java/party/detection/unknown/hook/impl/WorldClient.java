package party.detection.unknown.hook.impl;

/**
 * @author GenericSkid
 * @since 8/10/2017
 */
public interface WorldClient extends World {

}
