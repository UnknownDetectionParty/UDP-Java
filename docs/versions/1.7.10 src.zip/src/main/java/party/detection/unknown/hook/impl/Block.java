package party.detection.unknown.hook.impl;

import party.detection.unknown.hook.Getter;

/**
 * @author GenericSkid
 * @since 8/11/2017
 */
public interface Block {
	@Getter("a")
	String getUnlocalizedName();
}
