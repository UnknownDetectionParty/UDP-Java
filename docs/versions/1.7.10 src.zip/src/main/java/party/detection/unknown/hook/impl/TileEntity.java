package party.detection.unknown.hook.impl;

/**
 * @author GenericSkid
 * @since 8/11/2017
 */
public interface TileEntity {

}
