package party.detection.unknown.hook;

public class InvalidHookException extends RuntimeException {
	public InvalidHookException(String msg) {
		super(msg);
	}
}
