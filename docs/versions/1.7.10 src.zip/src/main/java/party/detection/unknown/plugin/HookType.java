package party.detection.unknown.plugin;

/**
 * @author bloo
 * @since 8/14/2017
 */
public enum HookType {
	BEGIN, OFFSET, END;
}
