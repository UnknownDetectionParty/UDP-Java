package party.detection.unknown.hook.impl;

/**
 * @author bloo
 * @since 8/11/2017
 */
public interface GuiIngame extends Gui {}
