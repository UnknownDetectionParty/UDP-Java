package party.detection.unknown.hook.impl;

/**
 * @author bloo
 * @since 7/14/2017
 */
public interface EntityPlayerSP extends EntityPlayer {


}
